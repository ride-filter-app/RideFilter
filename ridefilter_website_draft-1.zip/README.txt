Ride Filter website draft

Files:
- index.html: one-page Hindi landing page with APK download link.

Before publishing:
1. Replace placeholder support email and WhatsApp number with real public support contacts.
2. Add real Privacy Policy, Terms & Conditions, and Refund/Cancellation Policy pages that match the app and payment process.
3. Test the APK download link and all page links.
4. Do not claim payment-provider approval; provider approval is separate.

Free publishing option: GitHub Pages using the existing RideFilter repository.
